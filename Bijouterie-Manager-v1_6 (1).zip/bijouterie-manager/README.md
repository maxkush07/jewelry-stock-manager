# Bijouterie Manager V1.6

Application PHP 8.1+ / SQLite pour inventaire de bijouterie, stock dormant, ventes, historique du cours de l’or et estimation théorique du métal en stock.

## Installation
1. Téléversez le contenu du dossier `bijouterie-manager` dans votre hébergement.
2. Activez PHP PDO SQLite (`pdo_sqlite`) et autorisez l'écriture dans `storage/` et `uploads/`.
3. Ouvrez `/install.php` et créez le compte administrateur.
4. Après l'installation, supprimez `install.php` du serveur.
5. Faites des sauvegardes régulières de `storage/app.sqlite` et `uploads/`.

## Cours de l'or
- Les cours historiques peuvent être importés en CSV (`price_date`, `price_per_gram`, `currency`, avec `source` et `notes` facultatifs).
- Le bouton « Synchroniser le cours spot actuel » récupère le cours XAU/USD via `https://api.gold-api.com/price/XAU`, convertit l'once troy en grammes (31,1034768 g) et enregistre le prix du jour en USD, puis le convertit dans la devise des cours choisie dans les Paramètres (taux de change du jour de la Banque centrale européenne, via api.frankfurter.dev).
- Cette synchronisation nécessite un accès HTTPS sortant depuis l'hébergement. Elle ne remplace pas un historique historique pluriannuel; pour cela, importez un CSV fiable.
- Attention : les comparaisons sont valides seulement si les cours et l'article sont dans la même devise. La valeur théorique du métal est une estimation, pas une offre de rachat.

## Sécurité / exploitation
- Utilisez HTTPS et un mot de passe administrateur unique d'au moins 10 caractères.
- Ne rendez pas le dossier `storage/` accessible publiquement; le `.htaccess` fourni bloque son accès sur Apache.
- Conservez les sauvegardes hors du serveur web.
- L'archive doit être testée sur l'hébergement réel, notamment l'accès réseau sortant et `pdo_sqlite`.


## V1.3 — Valeur théorique du métal
Dans Rapports, un tableau estime la valeur théorique de l’or contenu dans chaque article en stock : poids saisi × pureté (carats/24) × dernier cours de l’or fin par gramme enregistré dans la devise du cours de l’article. Cette estimation concerne uniquement le métal et ne constitue pas une évaluation commerciale ou une offre de rachat. Les devises différentes ne sont pas additionnées.


## V1.4 — Historique individuel
- Cliquez sur le nom d’un article dans l’inventaire pour ouvrir son historique.
- Affiche la durée de détention, l’évolution du cours de l’or, la valeur théorique du métal et la marge brute si l’article est vendu.
- Courbe individuelle construite à partir des cours réellement enregistrés en SQLite; aucune donnée historique n’est inventée.


## V1.5 — Correctifs et fiabilité
- **Cours de l'or** : le graphique et la liste sont filtrés par devise (CAD / USD / EUR) ; la synchronisation convertit le cours spot USD dans la devise des cours (taux BCE via Frankfurter) ; un cours saisi par erreur peut être supprimé (re-saisir la même date et devise le remplace aussi).
- **Rapports** : la date du cours de référence est affichée ; elle passe en rouge au-delà de 7 jours.
- **Modification d'un article** : la devise de l'article et celle de son cours d'or ne sont plus réécrites avec les paramètres actuels ; chaque modification est ajoutée à l'historique.
- **Ventes** : l'enregistrement est transactionnel et refusé si l'article n'est plus en stock (plus de doublon par double clic) ; la remise en stock est journalisée et efface la vente.
- **Suppression** : bouton « Supprimer l'article » dans la fiche, avec confirmation ; la photo associée est supprimée du disque (de même qu'une photo remplacée).
- **Sauvegarde** : Paramètres → « Télécharger une sauvegarde complète (.zip) » (base SQLite + photos). Restauration : remplacer `storage/app.sqlite` et le dossier `uploads/` par ceux de l'archive. Nécessite l'extension PHP `zip`.
- **Application installable** : le service worker passe en « réseau d'abord » (plus de fichiers périmés après une mise à jour) et ne met plus en cache les pages ni les photos. Les fichiers CSS/JS sont versionnés (`?v=`).

### Mise à jour depuis la V1.4
Remplacez `index.php`, `sw.js`, `README.md` et le dossier `assets/`. Ne touchez ni à `storage/` ni à `uploads/`. Aucune migration de base de données n'est nécessaire.


## V1.6 — Stock, rapports, photos, documents et étiquettes
- **Stock dormant à paliers** : couleurs dans l'inventaire (jaune dès 90 j, orange dès 180 j, rouge dès 365 j) ; le seuil « dormant » (90 / 180 / 365 j) se règle dans Paramètres et alimente le tableau de bord, les rapports et le filtre « Dormant ».
- **Alerte de hausse de l'or** : seuil en % réglable (10 % par défaut). Panneau d'alertes au tableau de bord, filtre « Or ▲ » et badge « à revoir » dans l'inventaire pour les articles en stock dont le cours de l'or a monté d'au moins ce pourcentage depuis l'achat.
- **Rapports** : filtres par période et par catégorie (raccourcis 3 mois / 12 mois / année / tout), ventes par mois en graphique (chiffre d'affaires et marge), délai moyen de vente, rotation du stock (coût des ventes ÷ stock moyen), tableau par catégorie, valeur du métal en stock.
- **Photos multiples** (8 max.) : redimensionnées à 1600 px, miniature de 360 px, orientation EXIF corrigée, métadonnées (dont la position GPS) retirées. Choix de la photo principale et suppression depuis la fiche. Nécessite l'extension PHP GD ; sans elle, les photos sont enregistrées telles quelles.
- **Pièces jointes** (10 max.) : certificat, facture fournisseur, évaluation d'assurance ou autre, en PDF ou image (10 Mo max.). Les documents sont stockés dans `storage/docs/` (inaccessible depuis le web) et ne s'ouvrent que si vous êtes connecté.
- **Étiquettes QR** : bouton « Étiquette QR » dans la fiche, « Étiquettes » dans l'inventaire (toute la liste filtrée, 200 max.). Format 50 × 30 mm (une par page) ou planche de 3 colonnes. Le QR code ouvre la fiche de l'article ; si vous n'êtes pas connecté, la connexion vous y ramène.
- **Scan sur téléphone** : page « Scanner » (caméra, QR code → fiche) et recherche manuelle. Le scan intégré demande HTTPS et un navigateur compatible (Chrome / Edge sur Android) ; sinon, utilisez l'appareil photo du téléphone.
- **Mobile** : la barre de navigation du bas affiche enfin toutes les pages (elle n'affichait que la page active).
- **Sauvegarde** : inclut désormais les documents et les miniatures.

### Mise à jour depuis la V1.5
Remplacez `index.php`, `sw.js`, `README.md` et le dossier `assets/`. Ne touchez ni à `storage/` ni à `uploads/`. La base de données est migrée automatiquement au premier chargement (nouvelle table des fichiers ; vos photos existantes sont reprises). Faites une sauvegarde de `storage/app.sqlite` avant la mise à jour.
Les limites d'envoi de fichiers dépendent de votre hébergement (`upload_max_filesize` et `post_max_size` de PHP) : elles sont rappelées dans la fiche article.
