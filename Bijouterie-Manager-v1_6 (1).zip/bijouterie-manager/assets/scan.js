// Bijouterie Manager — scan de QR code via la caméra (API BarcodeDetector).
(function () {
  var video = document.getElementById('scanVideo'), msg = document.getElementById('scanMsg'), btn = document.getElementById('scanStart');
  if (!video || !btn) return;
  var stream = null, timer = null, detector = null;
  function setMsg(t) { msg.textContent = t; }
  function stop() {
    if (timer) { clearInterval(timer); timer = null; }
    if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
    video.style.display = 'none'; btn.textContent = 'Démarrer le scan';
  }
  function route(raw) {
    var target = null;
    try {
      var u = new URL(raw, location.href), id = u.searchParams.get('id') || '';
      if (u.origin === location.origin && u.searchParams.get('page') === 'history' && /^\d+$/.test(id)) target = 'index.php?page=history&id=' + id;
    } catch (e) {}
    if (!target) target = 'index.php?page=inventory&q=' + encodeURIComponent(String(raw).slice(0, 120));
    stop(); location.href = target;
  }
  async function start() {
    if (!('BarcodeDetector' in window)) { setMsg('Le scan intégré n’est pas disponible sur ce navigateur. Utilisez l’appareil photo du téléphone pour scanner le QR code, ou la recherche manuelle.'); return; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { setMsg('Caméra indisponible : la page doit être ouverte en HTTPS.'); return; }
    try {
      detector = new BarcodeDetector({ formats: ['qr_code'] });
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      video.srcObject = stream; video.style.display = 'block'; await video.play();
      btn.textContent = 'Arrêter'; setMsg('Placez le QR code dans le cadre…');
      timer = setInterval(async function () {
        try { var codes = await detector.detect(video); if (codes.length && codes[0].rawValue) route(codes[0].rawValue); } catch (e) {}
      }, 300);
    } catch (e) {
      stop(); setMsg('Impossible d’accéder à la caméra (' + (e && e.name ? e.name : 'erreur') + '). Autorisez la caméra et vérifiez que la page est en HTTPS.');
    }
  }
  btn.addEventListener('click', function () { if (stream) stop(); else start(); });
  window.addEventListener('pagehide', stop);
})();
