function openSale(id,name){document.getElementById('saleItemId').value=id;document.getElementById('saleItemName').textContent=name;document.getElementById('saleModal').classList.remove('hidden');document.body.style.overflow='hidden'}function closeSale(){document.getElementById('saleModal').classList.add('hidden');document.body.style.overflow=''}document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeSale();const m=document.getElementById('itemModal');if(m)location.href='index.php?page=inventory'}});document.getElementById('saleModal')?.addEventListener('click',e=>{if(e.target.id==='saleModal')closeSale()});
(function(){const canvas=document.getElementById('goldChart');if(!canvas||!window.goldData||!window.goldData.length)return;const ctx=canvas.getContext('2d');const d=window.goldData;const w=canvas.clientWidth||600,h=canvas.height;const ratio=window.devicePixelRatio||1;canvas.width=w*ratio;canvas.height=h*ratio;ctx.scale(ratio,ratio);const pad={l:42,r:12,t:16,b:28};const vals=d.map(x=>x.price),min=Math.min(...vals),max=Math.max(...vals),range=max-min||1;ctx.font='10px DM Sans, sans-serif';ctx.strokeStyle='#e8ece5';ctx.fillStyle='#8b958d';ctx.lineWidth=1;for(let i=0;i<4;i++){const y=pad.t+(h-pad.t-pad.b)*i/3;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText((max-(range*i/3)).toFixed(2),2,y+3)}const pts=d.map((x,i)=>({x:pad.l+(w-pad.l-pad.r)*(d.length===1?0:i/(d.length-1)),y:pad.t+(h-pad.t-pad.b)*(1-(x.price-min)/range)}));ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.strokeStyle='#2c7558';ctx.lineWidth=2.5;ctx.stroke();pts.forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,3,0,Math.PI*2);ctx.fillStyle='#2c7558';ctx.fill()});ctx.fillStyle='#8b958d';if(d.length){ctx.fillText(d[0].date, pad.l,h-7);const last=d[d.length-1];const label=last.date;ctx.fillText(label,Math.max(pad.l,w-pad.r-55),h-7)}})();
if('serviceWorker'in navigator && location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));


// Graphique historique de l'or pour une fiche d'article (sans dépendance externe).
(function(){
 const canvas=document.getElementById('itemGoldChart'); const data=window.itemGoldSeries;
 if(!canvas||!Array.isArray(data)||data.length<2)return;
 const ctx=canvas.getContext('2d');
 function draw(){const dpr=window.devicePixelRatio||1;const w=canvas.clientWidth||600,h=canvas.clientHeight||180;canvas.width=w*dpr;canvas.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);const pad={l:48,r:14,t:14,b:30};const vals=data.map(x=>x.price);let min=Math.min(...vals),max=Math.max(...vals);if(min===max){min*=.95;max*=1.05;}const x=i=>pad.l+(w-pad.l-pad.r)*(i/(data.length-1));const y=v=>pad.t+(h-pad.t-pad.b)*(1-(v-min)/(max-min));ctx.font='11px system-ui';ctx.strokeStyle='rgba(140,150,145,.22)';ctx.fillStyle='#9ba8a0';ctx.lineWidth=1;for(let i=0;i<4;i++){const v=min+(max-min)*i/3,yy=y(v);ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText(v.toFixed(2),2,yy+4);}ctx.beginPath();data.forEach((p,i)=>{if(i===0)ctx.moveTo(x(i),y(p.price));else ctx.lineTo(x(i),y(p.price));});ctx.lineWidth=2.5;ctx.strokeStyle='#d7b56d';ctx.stroke();ctx.lineTo(x(data.length-1),h-pad.b);ctx.lineTo(x(0),h-pad.b);ctx.closePath();ctx.fillStyle='rgba(215,181,109,.12)';ctx.fill();ctx.fillStyle='#9ba8a0';ctx.textAlign='left';ctx.fillText(data[0].date, pad.l, h-8);ctx.textAlign='right';ctx.fillText(data[data.length-1].date,w-pad.r,h-8);}
 draw();window.addEventListener('resize',draw);
})();

// Graphique des ventes par mois (chiffre d'affaires et marge brute)
(function () {
  var canvas = document.getElementById('salesChart'), data = window.salesByMonth;
  if (!canvas || !Array.isArray(data) || !data.length) return;
  var ctx = canvas.getContext('2d');
  function fmt(v) { return Math.abs(v) >= 1000 ? (v / 1000).toFixed(1).replace('.0', '') + ' k' : String(Math.round(v)); }
  function draw() {
    var dpr = window.devicePixelRatio || 1, w = canvas.clientWidth || 600, h = canvas.clientHeight || 220;
    canvas.width = w * dpr; canvas.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    var pad = { l: 46, r: 10, t: 14, b: 28 }, vals = [0];
    data.forEach(function (d) { vals.push(d.rev, d.margin); });
    var max = Math.max.apply(null, vals), min = Math.min.apply(null, vals);
    if (max === min) max = min + 1;
    var innerW = w - pad.l - pad.r, innerH = h - pad.t - pad.b;
    function y(v) { return pad.t + innerH * (1 - (v - min) / (max - min)); }
    ctx.font = '10px system-ui, sans-serif'; ctx.lineWidth = 1;
    for (var i = 0; i < 4; i++) {
      var v = min + (max - min) * i / 3, yy = y(v);
      ctx.strokeStyle = 'rgba(140,150,145,.25)'; ctx.beginPath(); ctx.moveTo(pad.l, yy); ctx.lineTo(w - pad.r, yy); ctx.stroke();
      ctx.fillStyle = '#7b8580'; ctx.textAlign = 'left'; ctx.fillText(fmt(v), 2, yy + 3);
    }
    if (min < 0) { ctx.strokeStyle = 'rgba(90,100,95,.6)'; ctx.beginPath(); ctx.moveTo(pad.l, y(0)); ctx.lineTo(w - pad.r, y(0)); ctx.stroke(); ctx.fillStyle = '#7b8580'; ctx.textAlign = 'left'; ctx.fillText('0', 2, y(0) + 3); }
    var slot = innerW / data.length, bw = Math.max(3, Math.min(22, slot * 0.34)), step = Math.max(1, Math.ceil(data.length / Math.max(1, Math.floor(innerW / 44))));
    data.forEach(function (d, idx) {
      var cx = pad.l + slot * (idx + 0.5);
      [[d.rev, '#2c7558', -bw - 1], [d.margin, '#d7b56d', 1]].forEach(function (b) {
        var y0 = y(0), y1 = y(b[0]);
        ctx.fillStyle = b[1]; ctx.fillRect(cx + b[2], Math.min(y0, y1), bw, Math.max(1, Math.abs(y1 - y0)));
      });
      if (idx % step === 0) { ctx.fillStyle = '#7b8580'; ctx.textAlign = 'center'; ctx.fillText(d.label, cx, h - 10); }
    });
  }
  draw(); window.addEventListener('resize', draw);
})();
