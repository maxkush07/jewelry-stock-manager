/* Bijouterie Manager — générateur de QR Code minimal, sans dépendance.
   Mode octets (UTF-8), correction d'erreur M, versions 1 à 10 (jusqu'à 213 octets). */
(function (root) {
  'use strict';

  // [octets de correction par bloc, [[nb de blocs, octets de données par bloc], ...]]
  var EC_M = [null,
    [10, [[1, 16]]], [16, [[1, 28]]], [26, [[1, 44]]], [18, [[2, 32]]], [24, [[2, 43]]],
    [16, [[4, 27]]], [18, [[4, 31]]], [22, [[2, 38], [2, 39]]], [22, [[3, 36], [2, 37]]], [26, [[4, 43], [1, 44]]]
  ];
  var ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];

  // Arithmétique GF(256), polynôme 0x11D
  var EXP = new Array(512), LOG = new Array(256);
  (function () {
    var x = 1, i;
    for (i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11D; }
    for (i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  })();
  function gmul(a, b) { return (a === 0 || b === 0) ? 0 : EXP[LOG[a] + LOG[b]]; }

  function rsDivisor(deg) {
    var r = [], i, j, rt = 1;
    for (i = 0; i < deg - 1; i++) r.push(0);
    r.push(1);
    for (i = 0; i < deg; i++) {
      for (j = 0; j < r.length; j++) {
        r[j] = gmul(r[j], rt);
        if (j + 1 < r.length) r[j] ^= r[j + 1];
      }
      rt = gmul(rt, 2);
    }
    return r;
  }
  function rsRemainder(data, div) {
    var res = div.map(function () { return 0; });
    data.forEach(function (b) {
      var f = b ^ res.shift();
      res.push(0);
      div.forEach(function (c, i) { res[i] ^= gmul(c, f); });
    });
    return res;
  }

  function utf8(str) {
    if (typeof TextEncoder !== 'undefined') return Array.prototype.slice.call(new TextEncoder().encode(str));
    var s = unescape(encodeURIComponent(str)), o = [], i;
    for (i = 0; i < s.length; i++) o.push(s.charCodeAt(i));
    return o;
  }

  function dataCapacity(ver) {
    return EC_M[ver][1].reduce(function (a, g) { return a + g[0] * g[1]; }, 0);
  }

  function makeMatrix(size) {
    var m = [], i, j;
    for (i = 0; i < size; i++) { m.push([]); for (j = 0; j < size; j++) m[i].push(false); }
    return m;
  }

  function encode(text, forceMask) {
    var data = utf8(String(text)), ver = 0, v;
    for (v = 1; v <= 10; v++) {
      if (4 + (v < 10 ? 8 : 16) + data.length * 8 <= dataCapacity(v) * 8) { ver = v; break; }
    }
    if (!ver) throw new Error('Texte trop long pour le QR code');

    // 1. Flux de bits
    var bits = [];
    function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
    put(4, 4);
    put(data.length, ver < 10 ? 8 : 16);
    data.forEach(function (b) { put(b, 8); });
    var capBits = dataCapacity(ver) * 8;
    put(0, Math.min(4, capBits - bits.length));
    while (bits.length % 8) bits.push(0);
    for (var pad = 0xEC; bits.length < capBits; pad ^= 0xEC ^ 0x11) put(pad, 8);
    var bytes = [], i, j;
    for (i = 0; i < bits.length; i += 8) {
      var by = 0; for (j = 0; j < 8; j++) by = (by << 1) | bits[i + j];
      bytes.push(by);
    }

    // 2. Blocs + correction d'erreur + entrelacement
    var eccLen = EC_M[ver][0], div = rsDivisor(eccLen), blocks = [], pos = 0;
    EC_M[ver][1].forEach(function (g) {
      for (var k = 0; k < g[0]; k++) {
        var d = bytes.slice(pos, pos + g[1]); pos += g[1];
        blocks.push({ d: d, e: rsRemainder(d, div) });
      }
    });
    var out = [], maxD = Math.max.apply(null, blocks.map(function (b) { return b.d.length; }));
    for (i = 0; i < maxD; i++) blocks.forEach(function (b) { if (i < b.d.length) out.push(b.d[i]); });
    for (i = 0; i < eccLen; i++) blocks.forEach(function (b) { out.push(b.e[i]); });

    // 3. Matrice : motifs de fonction
    var size = ver * 4 + 17, m = makeMatrix(size), fn = makeMatrix(size);
    function setFn(x, y, dark) { m[y][x] = !!dark; fn[y][x] = true; }
    for (i = 0; i < size; i++) { setFn(6, i, i % 2 === 0); setFn(i, 6, i % 2 === 0); }
    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy++) for (var dx = -4; dx <= 4; dx++) {
        var dist = Math.max(Math.abs(dx), Math.abs(dy)), xx = cx + dx, yy = cy + dy;
        if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFn(xx, yy, dist !== 2 && dist !== 4);
      }
    }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var ap = ALIGN[ver], n = ap.length;
    for (i = 0; i < n; i++) for (j = 0; j < n; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) continue;
      for (var ay = -2; ay <= 2; ay++) for (var ax = -2; ax <= 2; ax++)
        setFn(ap[i] + ax, ap[j] + ay, Math.max(Math.abs(ax), Math.abs(ay)) !== 1);
    }
    function drawFormat(t, mask, mark) {
      var d = mask, rem = d, k;               // correction M = 00
      for (k = 0; k < 10; k++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      var bt = ((d << 10) | rem) ^ 0x5412;
      function bit(q) { return ((bt >>> q) & 1) !== 0; }
      function put2(x, y, v) { t[y][x] = v; if (mark) fn[y][x] = true; }
      for (k = 0; k <= 5; k++) put2(8, k, bit(k));
      put2(8, 7, bit(6)); put2(8, 8, bit(7)); put2(7, 8, bit(8));
      for (k = 9; k < 15; k++) put2(14 - k, 8, bit(k));
      for (k = 0; k < 8; k++) put2(size - 1 - k, 8, bit(k));
      for (k = 8; k < 15; k++) put2(8, size - 15 + k, bit(k));
      put2(8, size - 8, true);
    }
    drawFormat(m, 0, true);
    if (ver >= 7) {
      var r = ver, k2;
      for (k2 = 0; k2 < 12; k2++) r = (r << 1) ^ ((r >>> 11) * 0x1F25);
      var vb = (ver << 12) | r;
      for (k2 = 0; k2 < 18; k2++) {
        var col = ((vb >>> k2) & 1) !== 0, a = size - 11 + (k2 % 3), b = Math.floor(k2 / 3);
        setFn(a, b, col); setFn(b, a, col);
      }
    }

    // 4. Placement des données en zigzag
    var idx = 0, right, vert, jj;
    for (right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (vert = 0; vert < size; vert++) {
        for (jj = 0; jj < 2; jj++) {
          var x = right - jj, upward = ((right + 1) & 2) === 0, y = upward ? size - 1 - vert : vert;
          if (!fn[y][x] && idx < out.length * 8) {
            m[y][x] = ((out[idx >>> 3] >>> (7 - (idx & 7))) & 1) !== 0;
            idx++;
          }
        }
      }
    }

    // 5. Masque (meilleur des 8 selon la pénalité)
    function maskBit(mask, x, y) {
      switch (mask) {
        case 0: return (x + y) % 2 === 0;
        case 1: return y % 2 === 0;
        case 2: return x % 3 === 0;
        case 3: return (x + y) % 3 === 0;
        case 4: return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0;
        case 5: return (x * y) % 2 + (x * y) % 3 === 0;
        case 6: return ((x * y) % 2 + (x * y) % 3) % 2 === 0;
        default: return ((x + y) % 2 + (x * y) % 3) % 2 === 0;
      }
    }
    function penalty(t) {
      var p = 0, x, y, run, s, pos2, pat, c, dark = 0;
      for (y = 0; y < size; y++) {
        run = 1;
        for (x = 1; x < size; x++) { if (t[y][x] === t[y][x - 1]) run++; else { if (run >= 5) p += run - 2; run = 1; } }
        if (run >= 5) p += run - 2;
      }
      for (x = 0; x < size; x++) {
        run = 1;
        for (y = 1; y < size; y++) { if (t[y][x] === t[y - 1][x]) run++; else { if (run >= 5) p += run - 2; run = 1; } }
        if (run >= 5) p += run - 2;
      }
      for (y = 0; y < size - 1; y++) for (x = 0; x < size - 1; x++)
        if (t[y][x] === t[y][x + 1] && t[y][x] === t[y + 1][x] && t[y][x] === t[y + 1][x + 1]) p += 3;
      var pats = ['10111010000', '00001011101'];
      function scan(str) {
        for (var q = 0; q < 2; q++) { pat = pats[q]; pos2 = str.indexOf(pat); while (pos2 !== -1) { p += 40; pos2 = str.indexOf(pat, pos2 + 1); } }
      }
      for (y = 0; y < size; y++) {
        s = ''; for (x = 0; x < size; x++) { c = t[y][x]; s += c ? '1' : '0'; if (c) dark++; }
        scan(s);
      }
      for (x = 0; x < size; x++) { s = ''; for (y = 0; y < size; y++) s += t[y][x] ? '1' : '0'; scan(s); }
      p += Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10;
      return p;
    }
    var best = null, bestP = Infinity, mk, t, yy, xx;
    for (mk = 0; mk < 8; mk++) {
      if (forceMask != null && mk !== forceMask) continue;
      t = m.map(function (row) { return row.slice(); });
      for (yy = 0; yy < size; yy++) for (xx = 0; xx < size; xx++)
        if (!fn[yy][xx] && maskBit(mk, xx, yy)) t[yy][xx] = !t[yy][xx];
      drawFormat(t, mk, false);
      var pn = penalty(t);
      if (pn < bestP) { bestP = pn; best = t; }
    }
    return { size: size, version: ver, modules: best };
  }

  function toSVG(text, opt) {
    opt = opt || {};
    var q = encode(text), m = opt.margin == null ? 1 : opt.margin, n = q.size + 2 * m, d = '', x, y, s;
    for (y = 0; y < q.size; y++) {
      x = 0;
      while (x < q.size) {
        if (q.modules[y][x]) {
          s = x;
          while (x < q.size && q.modules[y][x]) x++;
          d += 'M' + (s + m) + ' ' + (y + m) + 'h' + (x - s) + 'v1h-' + (x - s) + 'z';
        } else x++;
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + n + ' ' + n + '" shape-rendering="crispEdges">' +
      '<rect width="' + n + '" height="' + n + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
  }

  var api = { encode: encode, toSVG: toSVG };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.QR = api;
})(typeof window !== 'undefined' ? window : this);
