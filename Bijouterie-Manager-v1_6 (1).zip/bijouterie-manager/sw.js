// Bijouterie Manager — service worker v1.6
// Réseau d'abord pour les ressources statiques : une mise à jour de l'application se charge
// toujours si le réseau répond ; le cache ne sert que de secours hors ligne.
// Les pages PHP, les photos et les données privées ne sont jamais mises en cache.
const CACHE = 'bijouterie-manager-v1-6';
const FILES = ['assets/style.css', 'assets/app.js', 'assets/qr.js', 'assets/scan.js', 'assets/icon.svg', 'manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || req.mode === 'navigate') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  const isStatic = /\/assets\/[^/]+$/.test(url.pathname) || /\/manifest\.json$/.test(url.pathname);
  if (!isStatic) return;
  e.respondWith(
    fetch(req)
      .then(res => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
        return res;
      })
      .catch(() => caches.match(req, { ignoreSearch: true }))
  );
});
